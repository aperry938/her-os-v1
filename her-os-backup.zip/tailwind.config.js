/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                her: {
                    red: '#D94436',
                    orange: '#E87C56',
                    cream: '#F2E8DC',
                    dark: '#2C1A1A',
                    soft: '#E6B8A2'
                },
                os: {
                    red: '#D94436',
                    orange: '#E87C56',
                    cream: '#F2E8DC',
                    dark: '#2C1A1A',
                    soft: '#E6B8A2'
                },
            },
            fontFamily: {
                sans: ['Inter', 'system-ui', 'sans-serif'],
            },
            animation: {
                'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
            }
        },
    },
    plugins: [],
}
