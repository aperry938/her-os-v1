import React from 'react';
import OSInterface from './components/OSInterface';

function App() {
    return (
        <OSInterface />
    );
}

export default App;
